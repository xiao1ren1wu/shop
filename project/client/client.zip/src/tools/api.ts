import { get, post } from './http';

const getTypeOne = () => get('http://192.168.204.18:1024/api/getTypeOne', {});
const getSwiper = () => get('http://192.168.204.18:1024/api/banner', {});
const getHottList = () => get('http://192.168.204.18:1024/api/hotList', {});
const getTypeTwo = (p: any) => get(`http://192.168.204.18:1024/api/getTypeTwo?type_one=${p}`, {});
const getGoodList = (p: any) => get(`http://192.168.204.18:1024/api/goodList?type_one=${p}`, {});
const getDetail = (p: any) => get(`http://192.168.204.18:1024/api/detail?goodId=${p}`, {});
const getSameList = (p: any) => get(`http://192.168.204.18:1024/api/sameList?supplier=${p}`, {});
const getSearch = (p: any) => get(`http://192.168.204.18:1024/api/search?word=${p}`, {});
const getNewList = (p: any) => get(`http://192.168.204.18:1024/api/newList?page=${p}`, {});
const loginApi = (p: any) => get(`http://192.168.204.18:1024/api/login?userName=${p.userName}&password=${p.password}`, {});
const registerApi = (p: any) => get(`http://192.168.204.18:1024/api/register?userName=${p.userName}&password=${p.password}`, {});
const getShopList = (p: any) => get(`http://192.168.204.18:1024/api/shopList?token=${p}`, {});
const getCarAdd = (p: any) => get(`http://192.168.204.18:1024/api/add?token=${p.token}&goodId=${p.goodId}`, {});
const carChangeApi = (p: any) => {
    switch (p.type) {
        case 'add':
            return get(`http://192.168.204.18:1024/api/add?token=${p.token}&goodId=${p.goodId}`, {})
        case 'sub':
            return get(`http://192.168.204.18:1024/api/remove?token=${p.token}&goodId=${p.goodId}`, {})
        case 'del':
            return get(`http://192.168.204.18:1024/api/del?token=${p.token}&goodId=${p.goodId}`, {})
    }
};
const getShopMsg = (p: any) => get(`http://192.168.204.18:1024/api/supplierList?supplier=${p.supplier}&page=${p.page}`, {});

export {
    getTypeOne,
    getSwiper,
    getHottList,
    getTypeTwo,
    getGoodList,
    getDetail,
    getSameList,
    getSearch,
    getNewList,
    loginApi,
    registerApi,
    getShopList,
    getCarAdd,
    carChangeApi,
    getShopMsg
}