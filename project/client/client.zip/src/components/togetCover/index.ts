import TargetCover from './TargetCover.vue'

export default {
    install(app: any) {
        app.component(TargetCover.name, TargetCover);
    }
}
