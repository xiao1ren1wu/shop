import GoTop from './goTop.vue'

export default {
    install(app: any) { 
        app.component(GoTop.name, GoTop)
    }
}
